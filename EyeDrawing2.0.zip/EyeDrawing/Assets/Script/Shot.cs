﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class Shot : MonoBehaviour
{
    public Camera PhotoCam;

    public Rect size;

    public RenderTexture _shot;

    public Draw draw;

    int photoNum=0;

    public LoadAllPic allPic;

    bool isEnter;

    string path = "";
    // public Btn_Start _Start;
    // Use this for initialization
    private void Awake()
    {
        path = DefaultDirectory() + "/Photo";
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }
    }
    void Start()
    {
       
        photoNum = PlayerPrefs.GetInt("PhotoNum");
        isEnter = false;
        Invoke("Delay", 5);
    }

    public Camera disCam;
    public Camera drawCam;


    public static bool reFresh = false;
    bool canBtn = true;
    // Update is called once per frame
    void Update()
    {
       // Debug.Log(isEnter);
        if (Input.GetKeyDown(KeyCode.Return)&&canBtn&&isEnter)
        {
            ScreenShot();
            canBtn = false;
           // Invoke("CanBtnDown", 2);
            isEnter = false;
            Invoke("Delay",12);

        }
        if (draw.can_write && disCam.gameObject.activeInHierarchy==true)
        {
            StartDraw();
        }
        else if(!draw.can_write && disCam.gameObject.activeInHierarchy ==false)
        {
            ReStart();
        }
    }
    void CanBtnDown()
    {
        canBtn = true;
    }
    public void StartDraw()
    {
       
        disCam.gameObject.SetActive(false);
        drawCam.gameObject.SetActive(true);
   

    }
    public void ReStart()
    {
        disCam.gameObject.SetActive(true);
        drawCam.gameObject.SetActive(false);
    }


    public void ScreenShot()
    {
        CaptureCamera(PhotoCam, size);
        draw.can_write = false;
        draw.Clear();
        //_Start.ReStart();
      
    }


    void Delay() {
        //Debug.Log("hand in");
       
        isEnter = true;
        canBtn = true;
    }
    /// <summary>  
    /// 对相机截图。   
    /// </summary>  
    /// <returns>The screenshot2.</returns>  
    /// <param name="camera">Camera.要被截屏的相机</param>  
    /// <param name="rect">Rect.截屏的区域</param>  
    void CaptureCamera(Camera camera, Rect rect)
    {
        // 创建一个RenderTexture对象  
        RenderTexture rt = new RenderTexture((int)rect.width, (int)rect.height, 0);
        // 临时设置相关相机的targetTexture为rt, 并手动渲染相关相机  
        camera.targetTexture = rt;
        camera.Render();
        //ps: --- 如果这样加上第二个相机，可以实现只截图某几个指定的相机一起看到的图像。  
        //ps: camera2.targetTexture = rt;  
        //ps: camera2.Render();  
        //ps: -------------------------------------------------------------------  

        // 激活这个rt, 并从中中读取像素。  
        RenderTexture.active = rt;
        Texture2D screenShot = new Texture2D((int)rect.width, (int)rect.height, TextureFormat.RGB24, false);
        screenShot.ReadPixels(rect, 0, 0);// 注：这个时候，它是从RenderTexture.active中读取像素  
        screenShot.Apply();
        allPic.allTex2d.Add(screenShot);
        // 重置相关参数，以使用camera继续在屏幕上显示  
        camera.targetTexture = _shot;
        //ps: camera2.targetTexture = null;  
        RenderTexture.active = null; // JC: added to avoid errors  
        GameObject.Destroy(rt);
        // 最后将这些纹理数据，成一个png图片文件  
        byte[] bytes = screenShot.EncodeToPNG();
        
        string filename =path +"/" + photoNum + ".jpg";

      //  Debug.Log(filename);
       /* if (photoNum == 40) {
            photoNum = 0;
        }*/
        photoNum++;
        System.IO.File.WriteAllBytes(filename, bytes);
       // Debug.Log(string.Format("截屏了一张照片: {0}", filename));
        reFresh = true;
        return;
    }
    private void OnApplicationQuit()
    {
        //photoNum = 0;
        PlayerPrefs.SetInt("PhotoNum", photoNum);
    }

     string DefaultDirectory()
    {
        string defaultDirectory = "";
        if (Application.platform == RuntimePlatform.OSXEditor)
        {
            defaultDirectory = System.Environment.GetEnvironmentVariable("HOME") + "/Desktop";
        }
        else
        {
            defaultDirectory = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop);
        }
        return defaultDirectory;
    }
}
