﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EyeLookAt : MonoBehaviour {
    public GameObject leftEye;
    public GameObject rightEye;

    public GameObject leftButton;
    public GameObject rightButton;

    public GameObject MoveButton;
    public GameObject arrow;


    bool isLeft, isRight,isMove;
    Vector2 left,right;
    float angle;
    // Use this for initialization
    void Start () {
        isLeft = false;
        isRight = false;
        isMove = false;
    }

    // Update is called once per frame
    void Update() {
        if (Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0)).x > -4 && Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0)).x < 6)
        {

            Vector2 left = Camera.main.ScreenToWorldPoint(Input.mousePosition) - leftEye.transform.position;
            angle = Mathf.Atan2(left.y, left.x) * Mathf.Rad2Deg;
            leftEye.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);


            Vector2 right = Camera.main.ScreenToWorldPoint(Input.mousePosition) - rightEye.transform.position;
            angle = Mathf.Atan2(right.y, right.x) * Mathf.Rad2Deg;
            rightEye.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

        }


        if (isLeft) {
            Vector2 left = Camera.main.ScreenToWorldPoint(Input.mousePosition) - leftButton.transform.position;
            angle = Mathf.Atan2(left.y, left.x) * Mathf.Rad2Deg;
            
            leftButton.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            leftEye.transform.rotation = leftButton.transform.rotation;


        }
        if (isRight)
        {
            Vector2 right = Camera.main.ScreenToWorldPoint(Input.mousePosition) - rightButton.transform.position;
            angle = Mathf.Atan2(right.y, right.x) * Mathf.Rad2Deg;
           
            rightButton.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            rightEye.transform.rotation = rightButton.transform.rotation;

        }

        if (isMove) {
              arrow.transform.position = new Vector3(arrow.transform.position.x,Camera.main.ScreenToWorldPoint(Input.mousePosition).y, arrow.transform.position.z);
            leftEye.transform.position = new Vector3(leftEye.transform.position.x, Camera.main.ScreenToWorldPoint(Input.mousePosition).y, leftEye.transform.position.z);
            rightEye.transform.position = new Vector3(rightEye.transform.position.x, Camera.main.ScreenToWorldPoint(Input.mousePosition).y, rightEye.transform.position.z);
        }

    }
    public void EndEye()
    {

        MoveButton.transform.position = arrow.transform.position;
        isLeft = false;
        isRight = false;
        isMove = false;
    }
    


    public void LeftButton() {
        isLeft = true;
    }

    public void RightButton()
    {
        isRight = true;
    }

    public void EyeMove() {
        isMove = true; 
    }
}
