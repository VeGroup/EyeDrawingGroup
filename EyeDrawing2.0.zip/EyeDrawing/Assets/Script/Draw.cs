﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using UnityEngine.UI;
using DG.Tweening;

public class Draw : MonoBehaviour {


    /// <summary>
    /// 鼠标画图功能
    /// </summary>

    private GameObject clone;
    private LineRenderer line;
    private int i;
    public GameObject tf;
    Color penColor;
    public GameObject[] pen;
    float layer;
    bool isEarse;
    public Transform father;
    List<GameObject> lineArr;
    int num;
    bool drawing;
    float t;
    int last;

    public Slider slider;
    float penSize;
    public GameObject penSizePic;


    void Start()
    {
        lineArr = new List<GameObject>();
        penColor = new Color(0, 0, 0);
        layer = 0.1f;
        penSize = 0.1f;
    }
    public bool can_write = false;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
        if (Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 220 - layer)).x > -4 && Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 220 - layer)).x < 6)
        {
            if (Input.GetMouseButtonDown(0))
            {
                can_write = true;
                clone = Instantiate(tf, tf.transform.position, transform.rotation, father);//克隆一个带有LineRender的物体
                                                                                                       //clone.gameObject.GetComponent<LineRendersTest>().enabled=false;
                                                                                                       //clone.GetComponent<LineRenderer>().enabled=true;
                line = clone.GetComponent<LineRenderer>();//获得该物体上的LineRender组件
                line.material.shader = Shader.Find("Legacy Shaders/Specular");
                line.material.color = penColor;//设置颜色
 
                lineArr.Add(clone);
                num++;
                if (isEarse)
                {
                    line.SetWidth(0.5f, 0.5f);
                }
                else
                {
                    line.SetWidth(penSize, penSize);
                }
                i = 0;
                layer = layer + 0.1f;
                drawing = true;
            }
            if (Input.GetMouseButton(0)&&drawing)
            {

                i++;
                line.SetVertexCount(i);//设置顶点数
                line.SetPosition(i - 1, Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 220 - layer)));//设置顶点位置
                                                                                                                                                //line.enabled=false;
            }

            if (Input.GetMouseButtonUp(0)) {
                drawing = false;
                t = 0;
            }

           
        }
        if (!drawing && t<35)
        {
            t += Time.deltaTime;
          
        }
        if (t > 30)
        {
            can_write = false;
        }

    }
    public void ReLast()
    {
        
        last = lineArr.Count - 1;
        if (last >= 0)
        {
            Destroy(lineArr[last].gameObject);
            lineArr.RemoveAt(last);
        }
    }


    public void Clear() {
        for (int i = lineArr.Count-1; i >= 0; i--) {
            Destroy(lineArr[i].gameObject);            
        }
        lineArr.Clear();
     
    }

    public void PenSize() {
        
        penSize = slider.value / 2;
        penSizePic.transform.DOScaleX(slider.value, 0.1f);
       
    }


    public void ChangeColor(int num) {
        isEarse = false;
        switch (num)
        {
            case 0:
                penColor = new Color(1f, 0f, 0f, 1);
                break;
            case 1:
                penColor = new Color(1f, 0.5f,0f, 1);
                break;
            case 2:
                penColor = new Color(1f, 1f,0f, 1);
                break;
            case 3:
                penColor = new Color(0f, 1f, 0f, 1);
                break;
            case 4:
                penColor = new Color(0f, 1f, 1f, 1);
                break;
            case 5:
                penColor = new Color(0f, 0f, 1f, 1);
                break;
            case 6:
                penColor = new Color(1f, 0f, 1f, 1);
                break;
            case 7:
                penColor = new Color(0f, 0f,0f, 1);
                break;
            case 8:
                penColor = new Color(1f, 1f, 1f, 1);
                isEarse = true;
                break;
        }

        for (int i = 0; i < 9; i++) {
           
            pen[i].transform.localPosition = new Vector3(pen[i].transform.localPosition.x ,- 4, pen[i].transform.localPosition.z);
         
        }
        pen[num].transform.localPosition = new Vector3(pen[num].transform.localPosition.x, -3, pen[num].transform.localPosition.z);
        penSizePic.GetComponent<SpriteRenderer>().color = penColor;
    }
}
