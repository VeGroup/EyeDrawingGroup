﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
public class Image_ChangeAni : MonoBehaviour {

    List<List<GameObject>> forceList = new List<List<GameObject>>();
    List<List<GameObject>> backList = new List<List<GameObject>>();

    Dictionary<string, List<List<Sprite>>> spritePath = new Dictionary<string, List<List<Sprite>>>();
    
    private float ImageWidth;
    private float ImageHeight;

    int currentImageNumber = 0;

    private LoadAllPic allPic;
    public Image image;

    public Draw draw;
	// Use this for initialization
	void Start () {
        allPic = GetComponent<LoadAllPic>();

        int count = transform.Find("force").childCount;
        for (int i = 0; i < count/8; i++)
        {
            List<GameObject> list = new List<GameObject>();
            for (int k = 0; k < count/4; k++)
            {
                list.Add(transform.Find("force").GetChild(k + i * 8).gameObject);
            }
            forceList.Add(list);
        }
        count = transform.Find("back").childCount;

        for (int i = 0; i < count/8; i++)
        {
            List<GameObject> list = new List<GameObject>();
            for (int k = 0; k < count/4; k++)
            {
                list.Add(transform.Find("back").GetChild(k + i * 8).gameObject);

            }
            backList.Add(list);
        }

        for (int i = 0; i < allPic.allTex2d.Count; i++)
        {
            List<List<Sprite>> spriteOneList = new List<List<Sprite>>();
            for (int j = 0; j < 4; j++)
            {
                List<Sprite> iSpriteList = new List<Sprite>();

                for (int k = 0; k < 8; k++)
                {
                    iSpriteList.Add(Sprite.Create(allPic.allTex2d[i], new Rect(new Vector2(allPic.allTex2d[i].width / 8 * k, allPic.allTex2d[i].height / 4 * j), new Vector2(allPic.allTex2d[i].width / 8, allPic.allTex2d[i].height / 4)), new Vector2(0, 0)));

                }
                spriteOneList.Add(iSpriteList);
            }
            spritePath.Add(i.ToString(), spriteOneList);
        }
        ImageWidth = forceList[0][0].GetComponent<RectTransform>().rect.width;
        ImageHeight = forceList[0][0].GetComponent<RectTransform>().rect.height;
        if (allPic.allTex2d.Count > 0)
        {
            SetSprite(0, true);
            SetSprite(0, false);
        }

        StartChangeImage();

    }
    public void AddSprite(Texture2D texture)
    {

        List<List<Sprite>> spriteOneList = new List<List<Sprite>>();
        for (int i = 0; i < 4; i++)
        {
            List<Sprite> iSpriteList = new List<Sprite>();
            for (int k = 0; k < 8; k++)
            {
                iSpriteList.Add(Sprite.Create(texture, new Rect(new Vector2(texture.width / 8 * k, texture.height / 4 * i), new Vector2(texture.width / 8, texture.height / 4)), new Vector2(0, 0)));
            }
            spriteOneList.Add(iSpriteList);
        }
        spritePath.Add((allPic.allTex2d.Count).ToString(), spriteOneList);
        SpriteSet();
        currentImageNumber = allPic.allTex2d.Count-1 ;
        StartChangeImage();
    }
    List<Sprite> wholeSprite = new List<Sprite>();
    void SpriteSet()
    {
        wholeSprite = new List<Sprite>();
        for (int i = 0; i < allPic.allTex2d.Count; i++)
        {
            Sprite sprite = Sprite.Create(allPic.allTex2d[i], new Rect(0, 0, allPic.allTex2d[i].width, allPic.allTex2d[i].height), new Vector2(0.5f, 0.5f));
            
            wholeSprite.Add(sprite);
            if (i >= 32)
            {
                forceList[(i-32) / 8][(i-32) % 8].GetComponent<Image>().sprite = sprite;
            }
            else
            {
                forceList[i / 8][i % 8].GetComponent<Image>().sprite = sprite;
            }
            
        }

    }
    public void SetSprite(int ImageName, bool force)
    {
        List<List<Sprite>> spriteList;
        spritePath.TryGetValue(ImageName.ToString(), out spriteList);
        if (force)
        {
            //for (int i = 0; i < 4; i++)
            //{
            //    for (int k = 0; k < 8; k++)
            //    {
            //        forceList[3 - i][k].GetComponent<Image>().sprite = spriteList[i][k];
            //    }
            //}
            SpriteSet();
        }
        else
        {
            //for (int i = 0; i < 4; i++)
            //{
            //    for (int k = 0; k < 8; k++)
            //    {
            //        backList[3 - i][k].GetComponent<Image>().sprite = spriteList[i][k];
            //    }
            //}

            //Sprite sprite = Sprite.Create(allPic.allTex2d[ImageName], new Rect(0, 0, allPic.allTex2d[ImageName].width, allPic.allTex2d[ImageName].height), new Vector2(0.5f, 0.5f));
            if (wholeSprite.Count > 0)
            {
                image.sprite = wholeSprite[ImageName];
            }
        }

    }

    public void StartChangeImage()
    {
        if (allPic.allTex2d.Count > 0)
        {
            SetSprite(currentImageNumber, false);
            currentImageNumber++;

            if (currentImageNumber >= allPic.allTex2d.Count)
            {
                currentImageNumber = Random.Range(0, allPic.allTex2d.Count);
            }
        }
        curAnim = Random.Range(1, 3);

        StartImageAnim(curAnim);

        Invoke("ResetForce"+curAnim, 5);
    }
    int curAnim = 0;
    public void StartImageAnim( int currentAnim)
    {
        Invoke("AnimType" + currentAnim, 0);
    }

    public void ResetForce1()
    {
        SetSprite(currentImageNumber, true);
        float Time = 0.3f;
        List<Tweener> tweenrs = new List<Tweener>();
        for (int i = 0; i < forceList.Count; i++)
        {
            for (int k = 0; k < forceList[i].Count; k++)
            {

                Tweener tweenr = forceList[i][k].GetComponent<RectTransform>().DORotate(new Vector3(0, 0, 0), 1f).SetEase(Ease.InBack).SetDelay(Time);



                Time += 0.1f;
            }
        }
        if (!draw.can_write)
        {
            Invoke("StartChangeImage", 10);
        }
    }
    public void ResetForce2()
    {
        SetSprite(currentImageNumber, true);
        float Time = 0.3f;
        List<Tweener> tweenrs = new List<Tweener>();
        for (int i = 0; i < forceList.Count; i++)
        {
            for (int k = 0; k < forceList[i].Count; k++)
            {

                Tweener tweenr = forceList[i][k].GetComponent<RectTransform>().DOScale(new Vector3(1.05f,1.05f,1.05f),0.8f).SetEase(Ease.OutSine).SetDelay(Time);



                Time += 0.05f;
            }
        }

        if (!draw.can_write)
        {
            Invoke("StartChangeImage", 10);
        }
    }

    public void AnimType1()
    {
        float Time = 0.25f;
        List<Tweener> tweenrs = new List<Tweener>();
        for (int i = 0; i < forceList.Count; i++)
        {
            for (int k = 0; k < forceList[i].Count; k++)
            {

                Tweener tweenr = forceList[i][k].GetComponent<RectTransform>().DORotate(new Vector3(0, 90, 0), 1f).SetEase(Ease.InBack).SetDelay(Time);



                Time += 0.1f;
            }
        }     
    }
   
    public void AnimType2()
    {
        float Time = 0.25f;
        for (int i = 0; i < forceList.Count; i++)
        {
            for (int k = 0; k < forceList[i].Count; k++)
            {
                forceList[i][k].GetComponent<RectTransform>().DOScale(0, 0.8f).SetEase(Ease.InCirc).SetDelay(Time);
                Time += 0.05f;
            }
        }
    }
   

    // Update is called once per frame
    void Update () {
		
	}
}
