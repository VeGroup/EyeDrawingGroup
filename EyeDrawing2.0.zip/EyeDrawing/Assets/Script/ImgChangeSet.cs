﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
public class ImgChangeSet : MonoBehaviour {

    List<List<GameObject>> foreList = new List<List<GameObject>>();
    Dictionary<string, List<List<Sprite>>> spritePath = new Dictionary<string, List<List<Sprite>>>();
    int currentImageNumber = 0;
    private LoadAllPic allpic;
    public Image image;
    public Draw draw;

    Counter counter;

	// Use this for initialization
	void Start () {
        allpic = GetComponent<LoadAllPic>();
        int count = transform.Find("force").childCount;
        counter = GetComponent<Counter>();
        for (int i = 0; i < count/8; i++)
        {
            List<GameObject> list = new List<GameObject>();
            for (int j = 0; j < count/4; j++)
            {
                list.Add(transform.Find("force").GetChild(j + i * 8).gameObject);
            }
            foreList.Add(list);
        }
        SpriteSet();
        if (allpic.allTex2d.Count > 0)
        {
            SetSprite(0, true);
            SetSprite(0, false);
        }

        StartChangeImage();

    }
    
    public void AddSprite(Texture2D texture)
    {



        currentImageNumber = allpic.allTex2d.Count - 1;
        Debug.Log("currentImageNumber" + currentImageNumber);
       
        
        AddSpriteSet(true);
        StartChangeImage();

    }


    List<Sprite> wholeSprite = new List<Sprite>();
    void SpriteSet()
    {
        wholeSprite = new List<Sprite>();
        for (int i = 0; i < allpic.allTex2d.Count; i++)
        {
            Sprite sprite = Sprite.Create(allpic.allTex2d[i], new Rect(0, 0, allpic.allTex2d[i].width, allpic.allTex2d[i].height), new Vector2(0.5f, 0.5f));

            wholeSprite.Add(sprite);
            if (i >= 32)
            {
                foreList[(i - 32) / 8][(i - 32) % 8].GetComponent<Image>().sprite = sprite;
            }
            else
            {
                foreList[i / 8][i % 8].GetComponent<Image>().sprite = sprite;
            }

        }
    }

    void AddSpriteSet(bool _Add)
    {
        if (allpic.allTex2d.Count > 0)
        {
            int count = allpic.allTex2d.Count - 1;
           
            Sprite sprite = Sprite.Create(allpic.allTex2d[count], new Rect(0, 0, allpic.allTex2d[count].width, allpic.allTex2d[count].height), new Vector2(0.5f, 0.5f));

            if (count >= 32)
            {
                foreList[(count - 32) / 8][(count - 32) % 8].GetComponent<Image>().sprite = sprite;
            }
            else
            {
                foreList[count / 8][count % 8].GetComponent<Image>().sprite = sprite;
            }
            if (_Add)
            {
                wholeSprite.Add(sprite);
            }
        }
    }

    public void SetSprite(int ImageName,bool force)
    {
       
        if (force)
        {
            AddSpriteSet(false);
        }
        else
        {
            if (wholeSprite.Count > 0)
            {
                
                image.sprite = wholeSprite[ImageName];
            }
        }
    }

    int curAnim = 0;
    void StartChangeImage()
    {
        // curAnim = Random.Range(1, 4);
        curAnim = 1;
        if (!draw.can_write)
        {
            Invoke("ResetForce" + curAnim, 5);
            
        }
        else
        {
           
            
            ResetForce();
            return;
        }
       
        if (allpic.allTex2d.Count > 0)
        {
            SetSprite(currentImageNumber, false);
            currentImageNumber++;
            if (currentImageNumber >= allpic.allTex2d.Count)
            {
                currentImageNumber = Random.Range(0, allpic.allTex2d.Count);
            }

        }
        
        StartImageAnim(curAnim);
    }

    public void StartImageAnim(int currentAnim)
    {
        Invoke("AnimType" + currentAnim, 0);
    }

    public void ResetForce()
    {
        SetSprite(currentImageNumber, true);
        for (int i = 0; i < foreList.Count; i++)
        {
            for (int k = 0; k < foreList[i].Count; k++)
            {
                foreList[i][k].GetComponent<RectTransform>().localEulerAngles = Vector3.zero;
                foreList[i][k].GetComponent<RectTransform>().localScale = new Vector3(1.05f,1.05f,1.05f);
            }
        }
    }

    public void ResetForce1()
    {
        
        if (!draw.can_write)
        {
           
            Invoke("StartChangeImage", 10);
        }
        else
        {
            ResetForce();
            return;
        }
        SetSprite(currentImageNumber, true);
        float Time = 0.3f;
       
        for (int i = 0; i < foreList.Count; i++)
        {
            for (int k = 0; k < foreList[i].Count; k++)
            {

                foreList[i][k].GetComponent<RectTransform>().DORotate(new Vector3(0, 0, 0), 1f).SetEase(Ease.InBack).SetDelay(Time);



                Time += 0.1f;
            }
        }
       
    }
    public void ResetForce2()
    {
        
        if (!draw.can_write)
        {
            Debug.Log(draw.can_write);
            Invoke("StartChangeImage", 10);
        }
        else
        {
            ResetForce();
            return;
        }
        SetSprite(currentImageNumber, true);
        float Time = 0.3f;
       
        for (int i = 0; i < foreList.Count; i++)
        {
            for (int k = 0; k < foreList[i].Count; k++)
            {

                foreList[i][k].GetComponent<RectTransform>().DOScale(new Vector3(1.05f, 1.05f, 1.05f), 0.8f).SetEase(Ease.OutSine).SetDelay(Time);



                Time += 0.05f;
            }
        }
        

    }
    public void ResetForce3()
    {

        if (!draw.can_write)
        {
            Debug.Log(draw.can_write);
            Invoke("StartChangeImage", 10);
        }
        else
        {
            ResetForce();
            return;
        }
        SetSprite(currentImageNumber, true);
        float Time = 0.3f;

        for (int i = 0; i < foreList.Count; i++)
        {
            for (int k = 0; k < foreList[i].Count; k++)
            {

                foreList[i][k].GetComponent<CanvasGroup>().DOFade(1, 1f).SetEase(Ease.InBack).SetDelay(Time);



                Time += 0.05f;
            }
        }

    }

    public void AnimType1()
    {
        float Time = 0.25f;
       
        for (int i = 0; i < foreList.Count; i++)
        {
            for (int k = 0; k < foreList[i].Count; k++)
            {

               foreList[i][k].GetComponent<RectTransform>().DORotate(new Vector3(90, 0, 0), 1f).SetEase(Ease.InBack).SetDelay(Time);



                Time += 0.1f;
            }
        }
       

    }

    public void AnimType2()
    {
        float Time = 0.25f;
        for (int i = 0; i < foreList.Count; i++)
        {
            for (int k = 0; k < foreList[i].Count; k++)
            {
                foreList[i][k].GetComponent<RectTransform>().DOScale(0, 0.8f).SetEase(Ease.InCirc).SetDelay(Time);
                Time += 0.05f;
            }
        }
    }
    public void AnimType3()
    {
        float Time = 0.25f;

        for (int i = 0; i < foreList.Count; i++)
        {
            for (int k = 0; k < foreList[i].Count; k++)
            {

                foreList[i][k].GetComponent<CanvasGroup>().DOFade(0, 1.5f).SetEase(Ease.InBack).SetDelay(Time);



                Time += 0.05f;
            }
        }

    }

    bool judgeInvoke = true;
    // Update is called once per frame
    void Update () {
        if (draw.can_write&&judgeInvoke)
        {
            
            CancelInvoke();
            Invoke("ResetForce",4);
            judgeInvoke = false;
        }
        else if(!draw.can_write)
        {
            judgeInvoke = true;
        }
	}
}
