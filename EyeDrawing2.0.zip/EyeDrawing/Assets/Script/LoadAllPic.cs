﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class LoadAllPic : MonoBehaviour
{

	 public GameObject StoreObj;
    private ImgSort imgSort;
    // 储存获取到的图片  
    [HideInInspector]
    public  List<Texture2D> allTex2d = new List<Texture2D>();

  //  public Transform par;

    private ImgChangeSet imageManager;
    // Use this for initialization  
   
    private void Start()
    {
        imgSort = GetComponent<ImgSort>();
        imageManager = GetComponent<ImgChangeSet>();
        load();
        // imgSort.Init();
    }
    private void Update()
    {
        if (Shot.reFresh)
        {
            AddImg();
        }
    }

    void AddImg()
    {
        //load();
      //  GameObject temp = GameObject.Instantiate(StoreObj, StoreObj.transform.position, Quaternion.identity);
        
        //temp.GetComponent<Transform>().SetParent(par);
       // temp.GetComponent<Transform>().localScale = Vector3.one;
       // temp.GetComponent<RectTransform>().anchoredPosition3D = Vector3.zero;
        Sprite sprite = Sprite.Create(allTex2d[allTex2d.Count-1], new Rect(0, 0, allTex2d[allTex2d.Count - 1].width, allTex2d[allTex2d.Count - 1].height), new Vector2(0.5f, 0.5f));
       // temp.GetComponent<Image>().sprite = sprite;
       // temp.transform.name = "Element" + (allTex2d.Count - 1);

        imageManager.AddSprite(allTex2d[allTex2d.Count - 1]);
        Shot.reFresh = false;
    }


    void ImgLoad()
    {
        load();
        for (int i = 0; i < allTex2d.Count; i++)
        {
            
            GameObject temp = GameObject.Instantiate(StoreObj, StoreObj.transform.position, Quaternion.identity);
          //  temp.GetComponent<Transform>().SetParent(par);
            temp.GetComponent<Transform>().localScale = Vector3.one;
            temp.GetComponent<RectTransform>().anchoredPosition3D = Vector3.zero;
            Sprite sprite = Sprite.Create(allTex2d[i], new Rect(0, 0, allTex2d[i].width, allTex2d[i].height), new Vector2(0.5f, 0.5f));
            temp.GetComponent<Image>().sprite = sprite;
            temp.transform.name = "Element" + i;
        }
    }
    List<string> filePaths = new List<string>();
    void load()
    {
       
        string imgtype = "*.JPG|*.GIF|*.PNG";
        string[] ImageType = imgtype.Split('|');
        string[] dirs = Directory.GetFiles((DefaultDirectory() + "/Photo/"), "*.JPG");

        for (int j = 0; j < dirs.Length; j++)
        {
            if (!filePaths.Contains(dirs[j]))
            {
              
                filePaths.Add(dirs[j]);
            }
        }
        /* for (int i = 0; i < ImageType.Length; i++)
         {
             //获取Application.dataPath文件夹下所有的图片路径  

         }*/
     
        for (int i = 0; i < filePaths.Count; i++)
        {
           
                Texture2D tx = new Texture2D(100, 100);
                tx.LoadImage(getImageByte(filePaths[i]));
            if (allTex2d.Count < i + 1)
            {
                allTex2d.Add(tx);
            }
            
            
        }
       
    }

    /// <summary>  
    /// 根据图片路径返回图片的字节流byte[]  
    /// </summary>  
    /// <param name="imagePath">图片路径</param>  
    /// <returns>返回的字节流</returns>  
    private static byte[] getImageByte(string imagePath)
    {
        FileStream files = new FileStream(imagePath, FileMode.Open);
        byte[] imgByte = new byte[files.Length];
        files.Read(imgByte, 0, imgByte.Length);
        files.Close();
        return imgByte;
    }
    string DefaultDirectory()
    {
        string defaultDirectory = "";
        if (Application.platform == RuntimePlatform.OSXEditor)
        {
            defaultDirectory = System.Environment.GetEnvironmentVariable("HOME") + "/Desktop";
        }
        else
        {
            defaultDirectory = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop);
        }
        return defaultDirectory;
    }
}
