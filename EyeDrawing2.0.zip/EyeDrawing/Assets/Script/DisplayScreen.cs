﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisplayScreen : MonoBehaviour {

    void Awake()
    {
        Screen.fullScreen = true;
        if (Display.displays.Length > 1)
        {
            Display.displays[1].Activate();
            Display.displays[1].SetRenderingResolution(Display.displays[1].systemWidth, Display.displays[1].systemHeight);
        }
           // Screen.SetResolution(Display.displays[i].renderingWidth, Display.displays[i].renderingHeight, true);
        
    }

}
