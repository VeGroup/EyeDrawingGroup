﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
public class Btn_Start : MonoBehaviour {

    public Camera disCam;
    public Camera drawCam;
    public  Draw draw;
    private CanvasGroup group;
	// Use this for initialization
	void Start () {
        group = GetComponent<CanvasGroup>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void OnClick()
    {
        group.alpha = 0;
        group.blocksRaycasts = false;
        disCam.gameObject.SetActive(false);
        drawCam.gameObject.SetActive(true);
        draw.enabled = true;
        
    }
    public void ReStart()
    {
        group.alpha = 1;
        group.blocksRaycasts = true;
        disCam.gameObject.SetActive(true);
        drawCam.gameObject.SetActive(false);

        draw.enabled = false;
    }

}
