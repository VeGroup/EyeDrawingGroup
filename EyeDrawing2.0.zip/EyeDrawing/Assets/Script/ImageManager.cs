﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using DG.Tweening;
/// <summary>
/// 第一步，将背部图片改为需要播放的图片
///第二步，将force的32个image，通过各种方式消失。
///第三步，将force的32个image的显示的图片改变为back的image显示的图片
///第四步，将force的32个image复原（也就是将位置，透明度等复原，因为2张图片一样，这里复原肉眼是看不出来的）
/// 第五步，重复第一步。
/// </summary>
public class ImageManager : MonoBehaviour {

    List<List<GameObject>> forceList = new List<List<GameObject>>();
    List<List<GameObject>> backList = new List<List<GameObject>>();
   
    Dictionary<string, List<List<Sprite>>> spritePath = new Dictionary<string, List<List<Sprite>>>();
    public int ImageNumber;
    private float ImageWidth;
    private float ImageHeight;
    int currentImageNumber = 1;

    private LoadAllPic allPic;
    void Start () {
        allPic = GetComponent<LoadAllPic>();
        //找到32张force图片
        int count = transform.Find("force").childCount;
        for (int i = 0; i < count/8; i++) {
            List<GameObject> list = new List<GameObject>();
            for (int k = 0; k < count/4; k++) {
                list.Add(transform.Find("force").GetChild(k+i*8).gameObject);
            }
            forceList.Add(list);
        }
        //找到32张back图片
        count = transform.Find("back").childCount;
        for (int i = 0; i < count / 8; i++)
        {
            List<GameObject> list = new List<GameObject>();
            for (int k = 0; k < count / 4; k++)
            {
                list.Add(transform.Find("back").GetChild(k + i * 8).gameObject);
            }
            backList.Add(list);
        }
        for (int name = 0; name <allPic.allTex2d.Count; name++) {
           // Texture2D t2d = Resources.Load(name.ToString(), typeof(Texture2D)) as Texture2D;
            List<List<Sprite>> spriteOneList = new List<List<Sprite>>();
            for (int i = 0; i < 4; i++)
        {
                List<Sprite> iSpriteList = new List<Sprite>();
            for (int k = 0; k < 8; k++)
            {
                    iSpriteList.Add(Sprite.Create(allPic.allTex2d[name], new Rect(new Vector2(allPic.allTex2d[name].width / 8 * k, allPic.allTex2d[name].height / 4 * i), new Vector2(allPic.allTex2d[name].width / 8, allPic.allTex2d[name].height / 4)), new Vector2(0, 0)));
            }
                spriteOneList.Add(iSpriteList);
        }
            spritePath.Add(name.ToString(), spriteOneList);
        }
        ImageWidth = forceList[0][0].GetComponent<RectTransform>().rect.width;
        ImageHeight = forceList[0][0].GetComponent<RectTransform>().rect.height;
        SetSprite(1,true);
        SetSprite(1,false);
        Invoke("StartChangeImage", 5f);
    }
    public void AddSprite(Texture2D texture)
    {
       
        List<List<Sprite>> spriteOneList = new List<List<Sprite>>();
        for (int i = 0; i < 4; i++)
        {
            List<Sprite> iSpriteList = new List<Sprite>();
            for (int k = 0; k < 8; k++)
            {
                iSpriteList.Add(Sprite.Create(texture, new Rect(new Vector2(texture.width / 8 * k, texture.height / 4 * i), new Vector2(texture.width / 8, texture.height / 4)), new Vector2(0, 0)));
            }
            spriteOneList.Add(iSpriteList);
        }
        spritePath.Add((allPic.allTex2d.Count-1).ToString(), spriteOneList);
    }
    void SpriteSet()
    {

    for (int i = 0; i < allPic.allTex2d.Count; i++)
      {
          Sprite sprite = Sprite.Create(allPic.allTex2d[i], new Rect(0, 0, allPic.allTex2d[i].width, allPic.allTex2d[i].height), new Vector2(0.5f, 0.5f));
            forceList[i / 8][i].GetComponent<Image>().sprite = sprite;
      }
 
    }
    //设置force32张图片的背景
    public void SetSprite(int ImageName, bool force) {
        List<List<Sprite>> spriteList;
        spritePath.TryGetValue(ImageName.ToString(), out spriteList);
        if (force)
        {
            //for (int i = 0; i < 4; i++)
            //{
            //    for (int k = 0; k < 8; k++)
            //    {
            //        forceList[3 - i][k].GetComponent<Image>().sprite = spriteList[i][k];
            //    }
            //}
            SpriteSet();
        }
        else {
            for (int i = 0; i < 4; i++)
            {
                for (int k = 0; k < 8; k++)
                {
                    backList[3-i][k].GetComponent<Image>().sprite = spriteList[i][k];
                }
            }

        }

    }
    //设置一张图片背景////todo
    public void SetOneSprite(GameObject crImageName,int ImageName, bool force,int k,int i)
    {
        List<List<Sprite>> spriteList;
        spritePath.TryGetValue(ImageName.ToString(), out spriteList);
        if (force)
        {
            crImageName.GetComponent<Image>().sprite = spriteList[3-i][k];
        }
        else
        {
             crImageName.GetComponent<Image>().sprite = spriteList[3-i][k];
        }
    }
    int zy = 1;
    //轮播
    public void StartChangeImage() {
        ResetForce();//复原force图片，这张图片应该是当前back显示的图片
        //SetSprite(currentImageNumber, false);
        currentImageNumber++;
        if (currentImageNumber >= allPic.allTex2d.Count)
        {
            currentImageNumber = 0;
        }
        
       // StartImageAnim(Mathf.RoundToInt(Random.Range(1f,5f)));//改变动画效果

        StartImageAnim(zy++);
        if (zy == 6) {
            zy = 1;
        }
        Invoke("StartChangeImage", 5f);
        //设置back图片为一下轮播的图片
    }
    //更换图片
    public void SetNextImage(List<GameObject> objArray,Sprite newSprite) {
        for (int i = 0; i < objArray.Count; i++) {
            objArray[i].GetComponent<Image>().sprite = newSprite;
        }
    }
    //轮播动画
    public void StartImageAnim(int currentAnim) {
        //Invoke("AnimType" + currentAnim, 0);
        AnimType4();
    }
    //复原force
    public void ResetForce() {

        SetSprite(currentImageNumber, true);
      
        for (int i = 0; i < forceList.Count; i++)
        {
            for (int k = 0; k < forceList[i].Count; k++)
            {
                //forceList[i][k].GetComponent<CanvasGroup>().alpha = 1f;
                //forceList[i][k].GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
                //forceList[i][k].GetComponent<RectTransform>().localScale = Vector3.one;
                forceList[i][k].GetComponent<RectTransform>().localRotation = Quaternion.Euler(Vector3.zero);
                



            }
        }
       
    }

    //图片轮播动画的效果1
    public void AnimType1() {
        float Time = 0.2f;
        for (int i = 0; i < forceList.Count; i++)
        {
            for (int k = 0; k < forceList[i].Count; k++)
            {
                forceList[i][k].GetComponent<CanvasGroup>().DOFade(0,1.2f).SetDelay(Time);
                Time += 0.05f;
            }
        }
    }
    //图片轮播动画的效果2
    public void AnimType2()
    {
        float Time = 0.25f;
        for (int i = 0; i < forceList.Count; i++)
        {
            for (int k = 0; k < forceList[i].Count; k++)
            {
                forceList[i][k].GetComponent<RectTransform>().DOScale(0, 0.8f).SetEase(Ease.InBack).SetDelay(Time);
                Time += 0.05f;
            }
        }
    }
    //图片轮播动画的效果3
    public void AnimType3()
    {
        float Time = 0.25f;
        for (int i = 0; i < forceList.Count; i++)
        {
            for (int k = 0; k < forceList[i].Count; k++)
            {
                forceList[i][k].GetComponent<RectTransform>().DOScale(0, 0.8f).SetEase(Ease.InCirc).SetDelay(Time);
                Time += 0.05f;
            }
        }
    }
    //图片轮播动画的效果4
    public void AnimType4()
    {
        float Time = 0.25f;
        List<Tweener> tweenrs = new List<Tweener>();
        for (int i = 0; i < forceList.Count; i++)
        {
            for (int k = 0; k < forceList[i].Count; k++)
            {
                
                Tweener tweenr = forceList[i][k].GetComponent<RectTransform>().DORotate(new Vector3(90, 0, 0), 0.8f,RotateMode.LocalAxisAdd).SetEase(Ease.InBack).SetDelay(Time);
                
               
               
                Time += 0.05f;
            }
        }
    }
    //图片轮播动画的效果5
    public void AnimType5()
    {
        float Time = 0.2f;
        SetSprite(0,false);
        for (int i = 0; i < forceList.Count; i++)
        {
            for (int k = 0; k < forceList[i].Count; k++)
            {
                GameObject obj = forceList[i][k];
                int n = k;
                int m = i;
                Tweener tweener1 = forceList[i][k].GetComponent<RectTransform>().DOScale(0f, 0.4f).SetDelay(Time).OnComplete(()=>SetOneSprite(obj, currentImageNumber,true,n,m));
                Tweener tweener2 = forceList[i][k].GetComponent<RectTransform>().DOScale(1f, 0.4f).SetEase(Ease.OutBack);
                DOTween.Sequence().Append(tweener1).Append(tweener2);
                Time += 0.03f;
            }
        }
    }

}
